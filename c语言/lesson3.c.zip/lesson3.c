/*************************************************************************
	> File Name: lesson3.c
	> Author:fang 
	> Mail: 
	> Created Time: 四  3/17 16:17:58 2022
 ************************************************************************/

#include<stdio.h>
#include <string.h>
//7.1 函数的基本定义和使用 
//void fun1(){
//	int a = 99, b = 98;
//	printf("a = %d, b = %d", a, b);
//} 
//int main(){
//	fun1();
//}


//7.1 函数调用过程分析 
//void fun2();  // 函数声明 
//int main()
//{
//	int a=3,b=4;
//	fun();
//	printf("a+b=%d",a+b);
//} 
//void fun2()
//{
//	int c=4,d=5;
//	printf("c+d=%d\n",c+d);
//}


//7.2.1 变量的作用域 
//int a = 4, b = 5;
//void fun3(){
//	int a = 8, b = 10;
//	printf("\n\n以下为fun3输出：\n");
//	printf("a = %d, b = %d\n", a, b);
//	//printf("c = %d, d = %d\n", c, d);
//}
//int c = 16, d = 20;
//int main(){
//	printf("\n\n以下为main输出：\n");
//	printf("a = %d, b = %d\n", a, b);
//	printf("c = %d, d = %d\n", c, d);
//	fun3();
//}


//7.2.2 有参函数 
//void fun4(int x, int y){
//	x++;
//	y++;
//	printf("子函数：x = %d, y = %d\n", x, y);
//}
//int main(){
//	//int x = 80, y = 90;
//	//fun4(x, y);
//	//printf("主函数：x = %d, y = %d\n", x, y);
//	
//	int a = 80, b = 90;
//	fun4(a, b);
//	printf("主函数：a = %d, b = %d\n", a, b);
//	//printf("主函数：x = %d, y = %d\n", x, y);
//}


//7.3 函数的返回值 
//int fun5(int a, int b){
//	return a + b;
//}
//int main(){
//	int a = 1, b = 2;
//	int c = fun5(a, b);
//	printf("c = %d", c);
//}

//1、闰年的判断  （有参有返回值函数 ） 
//int fun6(int year){
//	if(year % 4 == 0 && year % 100 != 0 || year % 400 == 0)return 1;
//	else return 0;
//}
//int main(){
//	int year;
//	printf("请输入年份：");
//	scanf("%d", &year);
//	if(fun6(year)) printf("%d 是闰年\n", year);
//	else printf("%d 年是平年", year);
//} 


//2、 判断素数
//int fun7(int n){
//	for(int i = 2; i < n; i++){
//		if(n % i == 0) return 0;
//	}
//	return 1;
//} 
//int main(){
//	int n;
//	printf("请输入一个数：");
//	scanf("%d", &n);
//	if(fun7(n)) printf("%d 是素数\n", n);
//	else printf("%d 不是素数\n", n);
//}


// 3、编写函数fun,函数的功能是:根据以下公式计算s,计算结果作为函数值返回；n通过形参传入。
//s=1+1/(1+2)+1/(1+2+3)+.......+1/(1+2+3+4+......+n) 例如:若n的值为11时,函数的值为1.833333。
//int fun9(int i){
//	int sum = 0;
//	for(int j = 1; j <= i; j++){
//		sum += j;
//	}
//	return sum;
//}
//float fun8(int n){
//	float s = 0;
//	for(int i = 1; i <= n; i++){
//		s += 1.0 / fun9(i); //注意此处 / 需要强制转换 
//	}
//	return s;
//}
//int main(){
//	int n;// 项 
//	float s;//和 
//	printf("请输入项数：");
//	scanf("%d", &n);
//	s = fun8(n);
//	printf("%d项的结果是%f\n", n, s); 
//} 


//方法二：两个函数求结果
//float fun8(int n){
//	float s = 0;
//	for(int i = 1; i <= n; i++){
//		int sum = 0;
//		for(int j = 1; j <= i; j++){
//			sum += j;
//		} 
//		s += 1.0 / sum; //注意此处 / 需要强制转换 
//	}
//	return s;
//}
//int main(){
//	int n;// 项 
//	float s;//和 
//	printf("请输入项数：");
//	scanf("%d", &n);
//	s = fun8(n);
//	printf("%d项的结果是%f\n", n, s); 
//} 





//3 求100~200之间的全部素数之和。
/*int fun(int n){
    for(int i = 2; i < n; i++){
        if(n % i == 0)
        return 0;  //发现被整除的数时说明不是素数，返回0
    }
    return 1;
}
int main(){
    int sum = 0;
    for(int n = 100; n <= 200; n++){
        if(fun(n)) sum += n; //若i是素数则求和
    }
    printf("sum = %d\n", sum);
}*/



//广东工业大学  2019年
//3.有一个一维整型数组 array[10]，编写程序，求数组元素的平均值。
//要求∶求数组元素的平均值的功能用一个函数 average 实现
//在主函数中实现数组输入，并输出所求得的平均值（平均值按两位小数输出）。（15分）
/*float average(int array[]){
    double sum = 0;
    for(int i = 0; i < 10; i++){
        sum += array[i];
    }
    return sum/10;
}
int main(){
    int array[10];
    for(int i = 0; i < 10; i++){
        printf("请输入第%d个元素值：", i+1);
        scanf("%d", &array[i]);
    }
    printf("average : %.2f\n", average(array));
    return 0;
}
*/



//递归代码演示


// N的阶乘 
//int fun(int n){
//	if(n == 1)return 1;
//	else return fun(n-1)*n;
//}
//int main()
//{
//	int n;
//	printf("请输入n：");
//	scanf("%d", &n);
//	printf("%d 的阶乘是 %d", n, fun(n));
//	return 0;
//}


// 斐波那锲数列 
//int fun1(int n){
//	if(n == 1 || n == 2)
//	return 1;
//	else
//	return fun1(n-1) + fun1(n-2);
//}
//int main(){
//	int n;
//	printf("请输入n：");
//	scanf("%d", &n);
//	printf("%d 项为： %d", n, fun1(n));
//} 


// n的k次幂
//int fun2(int n, int k){
//	if(k == 1)
//	return n;
//	else
//	return n*fun2(n, k-1);
//}
//int main(){
//	int n, k;
//	printf("请输入n和k：");
//	scanf("%d%d", &n, &k);
//	printf("%d的%d次幂是：%d", n, k, fun2(n, k)); 
//} 


//答案：死循环 
//void recur(int num){
//	if(num == 0) return;
//	else printf("%d,", num);
//	recur(--num);
//}
//int main(){
//	recur(3);
//}


//判断数组升序 
//bool fun3(int a[], int n){
//	if(n == 1)
//	return true;
//	if(n == 2)
//	return a[1] >= a[0];
//	return fun3(a, n-1) && (a[n-1] >= a[n-2]);
//} 
//int main(){
//	int a[10]={23,4,56,78,90,109,120,130,133,135};
//	if(fun3(a,10)) printf("是");
//	else printf("否");
//}


//正整数转换为字符输出，递归实现
void fun4(int n){
	int i;
	i = n / 10;  // 583/10=58    58/10=5   5/10=0
	if(i) fun4(i);
	putchar(n % 10 + '0'); //执行运算，隐式转换 
}
int main(){
	int n;
	printf("请输入一个正整数n：");
	scanf("%d", &n);
	printf("转换后的字符串是：");
	fun4(n);
} 

// 数字输出还是字符输出，以及数字与字符之间的转换
//main(){
//	int n = 1;
//	//putchar(10+'0');
//	printf("%c\n", n+'0');  // 1
//	printf("%d", n+'0');  // 1+48('0'的ASCII码)=49
//}






/*int f(int x, int y){
    int r;
    if(y == 1) return x;
    else r = f(x, y-1) + x;
    return r;
}
int main(){
    int a = 6, b = 5;
    printf("%d\n", f(a, b));
}


int f(int n){
    if(n == 1) return 1;
    else return f(n-1)*n;
}
int main(){
    int num, bai, shi, ge;
    printf("请输入一个三位数：");
    scanf("%d", &num);
    bai = num / 100; shi = num / 10 % 10; ge = num % 10;
    if(num == f(bai) + f(shi) + f(ge))
    printf("%d 符合要求\n", num);
    else
    printf("%d 不符合要求\n", num);
}
*/

