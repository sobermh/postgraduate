/*************************************************************************
	> File Name: 1lesson.c
	> Author:fang 
	> Mail: 
	> Created Time: 一  3/14 15:38:32 2022
 ************************************************************************/

#include<stdio.h>
#define M(x,y) x%y
int main(){
    //题目：输入n个数，求最大值max和最小值min
    int x,amax,amin;
    printf("请输入一个数：");
    scanf("%d", &x);
    amax = x;//假设最强
    amin = x;//假设最弱
    while(x >= 0){
        if(x > amax) amax = x;
        if(x < amin) amin = x;
        scanf("%d", &x);
    }
    printf("max = %6d, min = %8d\n", amax, amin);



    /*int i;
    for(i = 0; i++ < 3;){
        ;
    }

    printf("i = %d", i);
    printf("%d\n", N*N);
    int a, b;
    printf("请输入两个数：");
    scanf("%d%d", &a, &b);
    printf("S = %d\n", M(a,b));




    double r, h, L, V;
    printf("请输入r和h：");
    scanf("%lf%lf", &r, &h);
    L = 2*3.14*r;
    V = 1/3.0*3.14*r*r*h;
    printf("L = %.2lf, V = %.2lf\n", L, V);

    int a,b;
    printf("请输入数字：");
    scanf("%d%d", &a, &b);
    printf("max = %d", a>b?a++:b++);
    printf("a = %d, b = %d", a, b);
    printf("%s", "12'fdfdfd'12");*/
    return 0;
}
