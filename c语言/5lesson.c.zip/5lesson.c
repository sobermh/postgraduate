/*************************************************************************
	> File Name: 5lesson.c
	> Author:fang 
	> Mail: 
	> Created Time: 三  4/ 6 13:28:21 2022
 ************************************************************************/

#include<stdio.h>
/*int main(){
    int a[5] = {10, 20, 30, 40, 50};
    //int b;
    int *p = a;
    //int *q = &b;//指向普通变量
   // printf("%d,", *p);//10
    //printf("%d,", *(p+1));//20
    //printf("%d,", *p++);//  *和++是单目运算符，结合自右向左，++在后面，所以在printf后执行
    //printf("%d, %d\n", *(++p), ++(*p));
    printf("a[2] = %d, p[2] = %d\n", a[2], p[2]);*/

    /*int *p, a[10], i;
    p = a;//指针指向数组
    //录入
    for(i = 0; i < 10; i++){
        *p++ = i;//逐个赋值
    }
    //输出
    p = a;//重新指向数组首位
    for(i = 0; i < 10; i++){
        printf("a[%d] = %d\n", i, *p++);
    }


}*/
//数组做参数，自函数执行数组加一

/*void fun(int *p){ //指针p指向了传递过来的首地址
    printf("\n自函数：");
    for(int i = 0; i < 5; i++){
        (*p)++; // 先取内容然后对内容进行加一
        printf("%d\t", *p++); //取内容，再指针指向后移一位
    }
}
int main(){
    int array[5] = {10, 20, 30, 40, 50};
    fun(array);//传递的是数组名，也就是首地址，空间共享
    printf("\n主函数：\n");
    for(int i= 0; i < 5; i++)
        printf("%d,", array[i]);//下标引用法
}*/

//1输入并查找最小值  2 删除最小值  3 输出删除后效果
/*#include <limits.h> //包含极值宏定义
int main(){
    int a[100], *p, i = 0;
    int min = INT_MAX, min_sub; //min存储最小值， min_sub存储最小值下标
    p = a;
    do{
        printf("请输入第%d个元素：", i+1);
        scanf("%d", p+i);
        if(*(p+i) < min && *(p+i) != -1){
            min = *(p+i);//存储最小值以及最小值下标
            min_sub = i;
        }
    }while(*(p + i++) != -1);

    //删除最小值:循环覆盖
    for(int j = min_sub + 1; j < i; j++){
        *(p + j -1) = *(p + j);//后面元素依次往前挪覆盖
    }
    //输出验证
    for(int j = 0; j < i-1; j++)
    printf("%d\t", *(p+j));

}*/

/*int main(){
    int a[3][4] = {0,1,2,3,4,5,6,7,8,9,10,11};
    printf("%p,", a);
    printf("%p,", *a);
    printf("%d,", *a[0]);
    printf("%p,", &a[0]);
    printf("%p\n", &a[0][0]);
}*/
//数组指针 ：指针，指向数组
int main(){
    int a[3][4] = {0,1,2,3,4,5,6,7,8,9,10,11};
    int (*p)[4];
    p = a;
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 4; j++){
            printf("%d\t", *(*(p+i)+j));
        }
        printf("\n");
    }
}

