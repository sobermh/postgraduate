/*************************************************************************
	> File Name: 6lesson.c
	> Author:fang 
	> Mail: 
	> Created Time: 五  4/ 8 18:16:05 2022
 ************************************************************************/

#include<stdio.h>
int main(){

    //单字符的读和写

    /*fputc('a', fp);
    rewind(fp);    
    putchar(fgetc(fp));*/
    //随机输入一个字符串写入文件，再读出输出到显示器

    /*puts("请输入字符串，以#字符结束：");
    char ch = getchar(); //键盘到内存
    while(ch != '#'){
        fputc(ch, fp);  //内存到文件
        ch = getchar();
    }
    rewind(fp);//文件位置指针回归到文件开始位置
    ch = fgetc(fp); //文件到内存
    while(ch != EOF) //EOF文件结束符
    {
        putchar(ch); //内存到显示器
        ch = fgetc(fp); //文件到内存
    }*/

    //字符串的读和写
    /*char str1[30], str2[30];
    puts("请输入字符串：");
    scanf("%s", str1);  //键盘到内存
    fputs(str1, fp); //内存到文件
    rewind(fp);
    fgets(str2, 5, fp);// 文件到内存
    puts(str2); //内存到显示器
    */


    //字符块内容的读和写(二进制)
    /*struct stu{
        int num;
        char name[20];
    }s1[10], s2[10];
    //从键盘输入内存s1
    printf("请输入数据：");
    for(int i = 0; i < 8; i++){
        scanf("%d%s", &s1[i].num, s1[i].name);
    }
    //从内存s1写入文件
    fwrite(s1, sizeof(struct stu), 5, fp);
    //从文件读出到内存s2
    rewind(fp);//回头是岸
    fread(s2, sizeof(struct stu), 5, fp);
    //从内存s2输出到显示器
    for(int i = 0 ;  i < 5; i++){
        printf("\n %d,  %s\n", s2[i].num, s2[i].name);
    }
    */


    //文件的打开和关闭
    FILE *fp = fopen("lagogo", "w+");
    if(fp == NULL){
        printf("该文件不存在\n");
        return 0;
    }

    //fprintf(fp,"%s", "abcdefg");
    //rewind(fp);
    //fseek(fp, 2, 0);
    //putchar(fgetc(fp));


    //格式化读和写
    /*int a;
    char str[20];
    printf("请输入一个整数和字符串：");
    scanf("%d%s", &a, str); //键盘到内存
    fprintf(fp, "%d%s", a, str); //内存到文件

    rewind(fp);

    int b; char str0[20];
    fscanf(fp, "%d%s", &b, str0); //文件到内存
    printf("\n %d,  %s \n", b, str0);// 内存到显示器
    */

    fclose(fp);
}
