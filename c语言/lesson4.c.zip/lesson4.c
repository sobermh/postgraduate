/*************************************************************************
	> File Name: lesson4.c
	> Author:fang 
	> Mail: 
	> Created Time: 一  3/21 16:03:26 2022
 ************************************************************************/

#include<stdio.h>
#include<string.h>
//字符数组的基本引入
//int main(){
//	char name[20] = "fang";
//	printf("%c\n", name[0]); //单个引用 
//	printf("%s", name);   //通过首地址引用整个字符串，遇到\0结束 
//}

//int main(){
//	char name[20] = {'h', 'e', 'l', 'l', 'o'};
//	char ch[] = "hello";
//	char a[] = {"hello"};
//	printf("name : %s, %d\n", name, strlen(name));
//	printf("ch : %s\n", ch);
//	printf("a : %s\n", a);
//} 




//字符数组的输入输出
//int main(){
//	char ch, str[10];
//	//scanf("%c%s", &ch, str);
//	//printf("%c\t%s", ch, str);
//
//	//ch = getchar();
//	//putchar(ch);
//
//	//gets(str);
//	//puts(str);
//
//	//scanf("%s", str); //i like you
//	//printf("%s", str);
//	//scanf("%[^\n]", str);
//	//puts(str);
//}


// 字符串函数
//int main(){
//	//char name1[20], name2[20];
////	puts("请输入姓名1：");
////	gets(name1);
////	puts("请输入姓名2：");
////	gets(name2);
////	puts(strcat(name1,name2));
////	puts(strcpy(name1,name2));

//	char ch1[] = "aabbcc", ch2[] = "aaabcc";
//	printf("\n比较结果：%d\n", strcmp(ch1, ch2));
//	printf("\nch1 的长度：%d, ch2 的长度：%d", strlen(ch1), strlen(ch2));	
//} 

/*
int main(){
    //字符数组中可以存储整型数
    char a[] = {0,1,2,3,4,97};
    printf("%d\n", a[5]);
    printf("%c\n", a[5]);
}
*/

// 北航21 五-6
//#include <ctype.h>
//void func6(char *s){  // char s[]
//	int i, t;
//	char c[80];
//	for(i = 0, t = 0; s[i]; i++){
//		if(!isspace(s[i]))
//			c[t++] = s[i];
//	}
//	c[t] = '\0';
//	strcpy(s, c);
//}
//int main(){
//	char s[] = "i love china ! \n \t";
//	func6(s);
//	printf("s : %s", s);
//} 


/*
int trim(char s[]){
    int n;
    for(n=strlen(s)-1; n>=0; n--)
	    if(s[n]!=' ' && s[n]!='\t' && s[n]!='\n') break;
    s[++n] ='\0';
    printf("%s\n", s);
    return n;
}   
int main(){
    //删除字符串末尾空白字符
    char s[]="jjlfd;fkd;\nfd*&%  9  \n\t";
    printf("字符串长度：%d\n", trim(s));
}*/



//北京师范大学  回文字符串
/*int fun(char f[]){
    int a = 0, b = strlen(f)-1;
    while(a <= b){
        if(f[a++] != f[b--]) return 0;
    }
    return 1;
}
int main(){
    char f[25];
    printf("enter string:");
    scanf("%s", f);
    if(fun(f)) printf("yes!\n");
    else printf("no!\n");
}*/



//指针
////指针变量的定义 
//int main(){
//	int *p1 = NULL;
//	float *p2 = NULL;
//	char *p3 = NULL;
//}

//指针变量的引用  *:1)定义指针变量 2)取所指向变量的内容 
//int main(){
//	int a1 = 99;
//	int *p1 = &a1;
//	printf("通过变量：%d，通过指针：%d\n", a1, *p1);
//	
//	int a2 = 89, *p2;
//	p2 = &a2;
//	printf("通过变量：%d，通过指针：%d\n", a2, *p2);
//	
//	//指针变量的指向关系发生改变
//	//p1 = p2;
//	//printf("p1指向：%d，p2指向：%d\n", *p1, *p2);
//	
i//	//*p2 = *p1;
//	//printf("*p1 = %d, *p2 = %d\n", *p1, *p2);
//} 



// 课堂案例
/*int main(){
	int x = 3, y, *px = &x;
	//y = *px + 5;// 8 
	//y = ++*px; // 4
	//y = *px++; // 3
	printf("y = %d\n", y);
} 
*/



//函数参数 课堂案例
//void swap(int a, int b){
//	int c;
//	c = a; a = b; b = c;
//	//printf("子函数：%d\t%d\n", a, b);
//}
//int main(){
//	int a, b;
//	printf("请输入两个整型数：");
//	scanf("%d%d", &a, &b);
//	if(a < b) swap(a, b);
//	printf("%d\t%d\n", a, b); 
//}

//void swap(int *p, int *q){
//	int a;
//	a = *p;
//	*p = *q;
//	*q = a;
//}
//第一种形式 :直接传地址 
//int main(){
//	int a, b;
//	printf("请输入两个整型数：");
//	scanf("%d%d", &a, &b);
//	if(a < b) swap(&a, &b);
//	printf("%d\t%d\n", a, b); 
//} 
// 第二种形式：传递指针 
//int main(){
//	int a, b;
//	int *pointer_1, *pointer_2;
//	printf("请输入两个整型数：");
//	scanf("%d%d", &a, &b);
//	pointer_1 = &a;
//	pointer_2 = &b;
//	if(a < b) swap(pointer_1, pointer_2);
//	printf("%d\t%d\n", a, b); 
//} 

/*
int main(){
    char *msg1;// = "aaabbbbbbbbbbbbaaaaaaaaa";
    //msg1 = "fjldsjfdljfdlfjdlfjd fdlsjffjdlf  fdsljfdlf";
    char msg2[20] = "fdfsdfdl";
    //printf("enter msg1:");
    //scanf("%s",msg1);  // 报错
    printf("enter msg2:");
    scanf("%s",msg2);
    printf("msg1: %s\n", msg1);
    printf("msg2: %s\n", msg2);
}*/


//广东工业大学  2019 指针加宏常量
/*#define  FUN(x,y) (x+2)*y
void sub(int *a, int *b)
{	
    int t;
    t = *a + *b;
    *a = t - *a;
    *b = t - *b;
}
int main()
{ 	
    int x=3, y=4, s;
    sub(&x,&y);
    s=36/FUN(x,y);
    printf("s=%d", s);
}*/

//指针指向数组
/*int main(){
    int a[5] = {0, 10, 20, 30, 40};
    int *p = a;
    printf("0 : %d\n", *(a+0));
    printf("1 : %d\n", *(p+1));
    printf("2 : %d\n", a[2]);
    printf("3 : %d\n", p[3]);
    
}*/


#include <limits.h> //各种数据类型的极值宏定义 
//请编写一程序，该程序的功能是找出而且删除一维整型数组 a[100]中的最小值元素。
//要求：
//1．数组各元素通过键盘输入获得初值；
//2．所有对数组元素的引用必须通过指针完成 
/*int main(){
	int a[100], *p, i = 0;
	int min = INT_MAX, min_sub;
    p = a;
    do{
        printf("请输入第%d个元素：", i + 1);
		scanf("%d", p + i);
		if(*(p + i) < min && *(p + i) != -1){
			min = *(p + i);
			min_sub = i;
		}
    }while(*(p + i++) != -1);
	
    //删除 
	for(int j = min_sub + 1; j < i; j++){
		*(p + j - 1) = *(p + j);
	}
	//输出
	for(int j = 0; j < i - 1 ; j++){
		printf("%d\t", *(p + j));
	} 
	printf("\n最小值是：%d\n", min);
	return 0;
}*/

/*
void func(int *s,int *y){
    static int t=3;
    *y=s[t];
    t--;
}
int main(){
    int a[]={10,20,30,40},i,x=0;
    for(i=0;i<4;i++){
        func(a,&x);
        printf("%d",x);
    }
    printf("\n");
}  */              









// 指针变量问题总结
//int main(){
//	int a = 23, *pa, *pb;
//	pa = &a;
//	pb = pa;
//	printf("pa = %d, pb = %d\n", *pa, *pb);

//	int arr[5] = {10,20,30,40,50}, *q1, *q2;
//	q1 = arr;
//	q2 = arr;
//	printf("%d\n", *++q1);
//	printf("%d\n", q2 - q1);

//	char const *pc;
//	pc = "C language";
//	printf("%s\n", pc);
//}


//int main(){
//	int a, b, c, *pmax, *pmin;
//	printf("请输入三个数：");
//	scanf("%d%d%d", &a, &b, &c);
//	if(a > b){
//		pmax = &a;
//		pmin = &b;
//	}else{
//		pmax = &b;
//		pmin = &a;
//	}
//	if(c > *pmax) pmax = &c;
//	if(c < *pmin) pmin = &c;
//	printf("max = %d\t min = %d\n", *pmax, *pmin);
//}





//int main()
//{
//	int ivar = 90;
//	int *iptr = &ivar;
//	printf("value of ivar:                          %d\n",ivar);
//	printf("value of ivar(by the iptr):             %d\n",*iptr);
//	printf("value of iptr(i.e.the address of ivar): %d\n",iptr);
//	printf("address of iptr:                        %d\n",&iptr);
//	return 0;
//}



//int main(){
//	int a = 90, *p = &a;
//	char b = 'c', *q = &b;
//	printf("a = %d, b = %c\n", *p, *q);
//	printf("指针：p_size = %d, q_size = %d\n", sizeof(p), sizeof(q));
//	printf("数据：a_size = %d, b_size = %d\n", sizeof(*p), sizeof(*q));
//}


//使用索引i获取数组a的元素，表达式为a[i]或*(a+i)，它涉及将a的
//地址加上i*sizeof(元素类型)的值，以获得对应的数组元素地址。
//指针版本相比之下需要的运算就少的多了，因为指针本身可递增
//不需要索引，并且指针直接指向所需的元素。
//int main(){

//	int a[5] = {1,2,3,4,5};
//	int *p = a;
//
//	for(int i = 0; i < 5; i++){
//		printf("%d\t", *(a+i));//wrong:*a++
//	}

//	for(int i = 0; i < 5; i++){
//		printf("%d\t", a[i]);
//	}
//
//	for(int i = 0; i < 5; i++){
//		printf("%d\t", *p++);
//	}
//}


