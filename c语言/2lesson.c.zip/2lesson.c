/*************************************************************************
	> File Name: 2lesson.c
	> Author:fang 
	> Mail: 
	> Created Time: 五  3/18 17:29:03 2022
 ************************************************************************/

#include<stdio.h>
int main(){
    /*int a = 4, b = 5;
    printf("余数：%d\n", a%b);
    printf("%f\n", (float)a / b);
    return 0;*/
    //关系运算符
    //printf("%d\n", 5>3<=0);// 0
    //printf("%d\n", 9!=8<7==9);//0

    //逻辑运算符
    //int a = 0, b = 2;
    //printf("%d\n", a && ++b);//短路运算
    //printf("b = %d\n", b);
    //
    //位运算符
    //printf("8 & 25 :%d\n", 8 & 25); // 8: 00001000  25: 00011001
    //printf(" ~8 = %d\n", ~8); // 8: 00001000  ~8: 11110111  取反：10001000  加一：10001001
    //所有的数码存储都是以补码形式，分正负。首位为0即为正数，正数的原码，反码，补码一样；首位为1代表负数，补码需要取反加一求原码

    //条件运算符结合性：当多个条件运算符放一个表达式中才考虑结合性，单个条件运算符只考虑先表达式1为真则执行表达式2
    //否则执行表达式3
    //int a = 2, b = 2;
    // printf("the result : %d\n", a > b ? ++a : ++b); //条件运算符运算规则：判断问号前表达式真假，为真执行冒号前，为假执行冒号后
    //printf("the result:%d\n", a>b ? a-- : (a != b ? a++ : b--));
    //printf("a = %d, b = %d\n", a, b);

    //案例1:循环求100以内奇数和，当大于20时退出循环，结果是？
    int sum = 0;
    for(int i = 1; i <= 100; i++){
        if(i % 2 == 1){
            sum += i;
            if(sum > 20) break;
        }
    }
    printf("sum = %d\n", sum);
    return 0;
    printf("hahahahahaha\n");
    printf("hahahahahaha\n");
    printf("hahahahahaha\n");
    printf("hahahahahaha\n");
    printf("hahahahahaha\n");
    printf("hahahahahaha\n");
}
